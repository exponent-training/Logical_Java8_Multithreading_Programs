import java.util.HashMap;
import java.util.Map;

public class Eachchractercount {

	public static void main(String[] args) {
		String str = "hhddjjsyyyttehhrryyrr";

		char ch[] = str.toCharArray();
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		for (Character c : ch) {
			Integer cnt = map.get(c);
			if (cnt == null) {
				map.put(c, 1);
			} else {
				cnt++;
				map.put(c, cnt);
			}
		}

		System.out.println(map);

	}
}
