
public class RemoveSpecialChracter {

	public static void main(String[] args) {

		String str = "$ex%po@net";

		System.out.println(str.replaceAll("[^a-zA-Z0-9]", ""));

	}

}
