package com.Exponent.String;

public class StringVCSCount {

	public static void main(String[] args) {

		String str = "Exponent^$%2121";
		int vCount = 0;
		int cCount = 0;
		int sCount = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o'
					|| str.charAt(i) == 'u' || str.charAt(i) == 'A' || str.charAt(i) == 'E' || str.charAt(i) == 'I'
					|| str.charAt(i) == 'O' || str.charAt(i) == 'U') {
				vCount++;
			} else if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') {
				cCount++;
			} else {
				sCount++;
			}
		}

		
		System.out.println(vCount);
		System.out.println(cCount);
		System.out.println(sCount);
		
	}

}
