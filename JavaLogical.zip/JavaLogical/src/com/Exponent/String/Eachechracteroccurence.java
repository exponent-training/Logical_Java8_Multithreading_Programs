package com.Exponent.String;

public class Eachechracteroccurence {

	public static void main(String[] args) {
		
		String str =  "eellttyypoeeee";
		int fl = str.length();
		int sl = str.replaceAll("e", "").length();//llttyypo
		System.out.println(fl-sl);
		

	}

}
