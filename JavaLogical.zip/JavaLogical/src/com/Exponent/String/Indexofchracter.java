package com.Exponent.String;

public class Indexofchracter {

	public static void main(String[] args) {
		int c = 0;
		String str = "expeeonent";
		int n = str.indexOf('z');
		System.out.println(n);
//		for (int i = 0; i < str.length(); i++) {
//			if (str.charAt(i) == 'e') {
//				// System.out.println("P at index " + i);
//				c++;
//			}
//		}
//		if (c == 0) {
//			System.out.println("yews");
//		} else {
//			System.out.println("Avaliable");
//		}

	}

}
