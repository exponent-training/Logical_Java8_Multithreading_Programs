package com.Exponent.String;

public class NoofChractersinaString {

	public static void main(String[] args) {

		String str = "Exponent IT";
		System.out.println(str.length());
		int cnt = 0;
		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) != ' ') {
				cnt++;
			}
		}

		System.out.println("without space:- " + cnt);

	}

}
