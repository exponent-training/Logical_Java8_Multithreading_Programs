package com.Exponent.LogocalProgramme;

public class PowerofNumber {

	public static void main(String[] args) {
		//1-10 even = cube 2,4,6,8,10
		int n = 2 , lc = 3;
		int pow=1;
		for(int i=1;i<=lc;i++)
		{
			pow = pow * n; 
		}

		System.out.println("cube of " + n + " = " + pow);
	}

}
