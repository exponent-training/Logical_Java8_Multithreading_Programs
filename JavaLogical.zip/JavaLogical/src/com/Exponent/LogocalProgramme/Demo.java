package com.Exponent.LogocalProgramme;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Your Number:-");
		int n = sc.nextInt();

		double f = 1;
		for (double i = 1; i <= n; i++) {
			f = f * i;
		}
		System.out.println("Fac IS : " + f);
	}

}
