package com.Exponent.LogocalProgramme;

import java.util.Scanner;

import javax.sound.midi.SysexMessage;

public class FebonacciSeriesA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter limit : ");
		int n = sc.nextInt();
		int a=0 ,b=1,c;
		System.out.print(a+" "+b);
		for(int i=2;i<=n;i++) {
			c=a+b;
			a=b;
			b=c;
			System.out.print(" "+c);
		}
		
		

	}

}
