package com.Exponent.LogocalProgramme;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter the number :-");
		int n = sc.nextInt();
		int temp = n;
		int rem , rev =0,sum=0;
		while(temp>0)
		{
			rem = temp % 10;
			rev  = rev * 10 + rem;
//			sum  += rem;
			temp = temp / 10;
		}
		
		// temp=n operation temp n==rev
		System.out.println("reverse number is :- " + rev);
		
		if(n == rev)
		{
			System.out.println("Palindrome number");
		}
		else
		{
			
			System.out.println("not palindrome");
		}

	}

}
