package com.Exponent.LogocalProgramme;

import java.util.Scanner;

public class SwappingNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the a:- ");
		int a = sc.nextInt();
		System.out.println("Enter the b:- ");
		int b = sc.nextInt();
		int c;

		System.out.println("****Before Swapping a and b***** ");
		System.out.println(a + " " + b);
		c = a;
		a = b;
		b = c;
		System.out.println("******After Swapping a and b**********");
		System.out.println(a + " " + b);

	}

}
