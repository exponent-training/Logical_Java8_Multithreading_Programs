package com.Exponent.LogocalProgramme;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Your Number:-");
		int n = sc.nextInt();

		int fac = 1;
		for (int i = 1; i <= n; i++) {
			fac = fac * i;
		}
		System.out.println("Fac IS" + fac);
	}

}
