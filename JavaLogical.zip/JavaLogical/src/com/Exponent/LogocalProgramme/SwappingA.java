package com.Exponent.LogocalProgramme;

import java.util.Scanner;

public class SwappingA {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("enter the no a:");
		int a = sc.nextInt();
		System.out.println("enter the no b:");
		int b = sc.nextInt();
		int c;
System.out.println("before Swapping "+a+"  " +b);
		c=a;
		a=b;
		b=c;
		System.out.println("after swaping"+a+" " +b);
	}
}
