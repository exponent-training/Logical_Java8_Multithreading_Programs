package com.Exponent.LogocalProgramme;

public class MultiplicationTable {

	public static void main(String[] args) {
		// 1-10 all tables
		int a = 2;
		for(int i=1;i<=10;i++)
		{
			System.out.println(a +" * "+ i + " = " + a*i  );
		}

	}

}
