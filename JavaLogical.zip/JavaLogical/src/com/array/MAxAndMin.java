package com.array;

import java.util.Arrays;

public class MAxAndMin {

	public static void main(String[] args) {

		int a[] = { 1, 25, 8, 4, 100 };

		int max = a[0];
		for (int i = 1; i < a.length; i++) {
			if (max < a[i]) {
				max = a[i];
			}
		}

		System.out.println(max);
	}
}
