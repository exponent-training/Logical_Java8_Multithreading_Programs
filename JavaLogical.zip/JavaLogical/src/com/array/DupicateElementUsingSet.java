package com.array;

import java.util.HashSet;
import java.util.Set;

public class DupicateElementUsingSet {
//each element count in array
//
	public static void main(String[] args) {
		int a[] = { 1, 5, 4, 8, 2, 2, 4, 8 };
		int cnt = 0;
		Set<Integer> set = new HashSet<Integer>();
		for (Integer v : a) {
			if (!set.add(v)) {
				cnt++;
				set.remove(v);
			}
		}
		System.out.println("non-duplicate:- " + set.size());
		System.out.println("duplicate elements:-" + cnt);
	}

}
