package com.array;

import java.util.Arrays;

public class arrayequality {

	public static void main(String[] args) {

		int a[] = { 1, 2, 3 };
		int b[] = { 1, 2, 3 };

		System.out.println(Arrays.equals(a, b));
	}
}
