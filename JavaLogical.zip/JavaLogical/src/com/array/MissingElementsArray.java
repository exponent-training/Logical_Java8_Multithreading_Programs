package com.array;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MissingElementsArray {

	public static void main(String[] args) {

		int a[] = { 1, 2, 4, 6, 8, 10, 55 };
		Arrays.sort(a);
		int size = 55;// LARGET NUMBER //SORT
		System.out.println(size);
		Set<Integer> set = new HashSet<Integer>();
		for (Integer v : a) {
			set.add(v);
		}
		System.out.println(set);

		for (int i = 1; i <= size; i++) {
			if (!set.contains(i)) {
				System.out.println(i);
			}
		}
	}

}
