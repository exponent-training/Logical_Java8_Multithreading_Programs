package com.array;

public class Reversearray {

	public static void main(String[] args) {
		
		int a[]  = {1,5,4,8,7,2};
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.print(a[i]);
		}
	}
}
