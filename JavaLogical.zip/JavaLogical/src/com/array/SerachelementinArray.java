package com.array;

public class SerachelementinArray {

	public static void main(String[] args) {

		int a[] = { 4, 88, 2, 5, 4, 7, 7, 5 };
		int cnt = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == 7) {
				cnt++;
			break;
			}
//			break;
		}
		System.out.println(cnt);
		if (cnt > 0) {
			System.out.println("Value present");
		} else {
			System.out.println("value not present");
		}
	}
}
