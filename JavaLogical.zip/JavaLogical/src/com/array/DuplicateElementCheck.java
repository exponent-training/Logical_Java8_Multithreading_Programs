package com.array;

public class DuplicateElementCheck {

	public static void main(String[] args) {

		int a[] = { 1, 5, 4, 8, 2, 2, 4, 8 };
		int cnt = 0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] != a[j]) {
					cnt++;
				}
			}
		}

		System.out.println("Duplicate element count " + cnt);
		if (cnt > 0) {
			System.out.println("Dupliacate");
		} else {
			System.out.println("Not duplicate");
		}

	}

}
