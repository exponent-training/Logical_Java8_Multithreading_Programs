package com.array;

public class Pairofsumarray {

	public static void main(String[] args) {

		int a[] = { 5, 8, 1, 2, 3, 4, 4, 2, 5, 6 };
		int sum = 8;
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] + a[j] == sum) {
					System.out.println("(" + a[i] + "," + a[j] + ")");
				}
			}
		}
	}
}
