package com.array;

public class EqualArrayCheck {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4 };
		int b[] = { 1, 2, 4, 3 };

		boolean flag = true;
		if (a.length == b.length) {
			for (int i = 0; i < a.length; i++) {
				if (a[i] != b[i]) {
					flag = false;
				}
			}
		} else {
			System.out.println("Not Equal");
		}

		if (flag) {
			System.out.println("Equal");
		} else {
			System.out.println("Not equal");
		}
	}
}
