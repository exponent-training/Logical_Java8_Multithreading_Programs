package com.array;

public class SumofElementinArray {

	public static void main(String[] args) {

		int a[] = { 1, 5, 4, 2 };
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum = sum + a[i];
		}
		System.out.println(sum);
	}
}
