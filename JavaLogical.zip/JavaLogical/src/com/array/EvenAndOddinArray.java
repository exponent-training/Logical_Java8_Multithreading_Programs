package com.array;

public class EvenAndOddinArray {

	public static void main(String[] args) {
		
		int a[] = {2,8,4,7,9,6,5,4};
		
		System.out.print("Even number:- ");
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
			}
		}
	}
}
