package com.Exponent.FunctionalInterfaceAndLE;

public class App {

	public void show() {
		System.out.println("From App");
	}

	public void m1() {
		System.out.println("From App m1");
	}

	public static void main(String[] args) {

		App a = new App() {

			public void show() {
				System.out.println("Annonymouse Clas");
			}

			public void m1() {
				System.out.println("From Annoynmouse m1");
			}
		};

		a.show();
		a.m1();
	}
}
