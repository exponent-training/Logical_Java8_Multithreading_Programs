package com.Exponent.FunctionalInterfaceAndLE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortingNumber {

	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<Integer>();

		numbers.add(33);
		numbers.add(2);
		numbers.add(45);
		numbers.add(55);

		Collections.sort(numbers, (Integer o1, Integer o2) -> {
			if (o1 > o2) {
				return -1;
			} else if (o1 < o2) {
				return 1;
			}

			return 0;
		});

		System.out.println(numbers);

	}

}
