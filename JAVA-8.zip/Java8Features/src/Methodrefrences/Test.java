package Methodrefrences;

public interface Test {

	public void ShowDetails();
}
