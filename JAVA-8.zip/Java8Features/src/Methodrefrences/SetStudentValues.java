package Methodrefrences;

public class SetStudentValues {

	public void Setstu() {
		Student s = new Student();
		s.setSid(1);
		s.setSname("xyz");
		System.out.println(s);
	}
}
