package Methodrefrences;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class App {
	public static void main(String[] args) {
//USING LAMBDA EXPRESSION
//		Test t = () -> SetStudentValues.Setstu();
//		t.ShowDetails();

		// USING METHOD REFERENCES for Static
		// syntax classname::refre.method

//		Test t1 = SetStudentValues::Setstu;
//		t1.ShowDetails();

		// USING METHOD REFERENCES for non-static
		// objectName::refre.method
		SetStudentValues stu = new SetStudentValues();

		Test t1 = stu::Setstu;
		t1.ShowDetails();

		System.out.println("==============================================");
		// foreach method refre.
		List<String> l = new ArrayList<String>();
		l.add("xyz");
		l.add("pqr");
		l.add("abc");

		l.forEach(System.out::println);

		// LocatDatetime Class
		DateTimeFormatter fd = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String ctime = LocalDateTime.now().format(fd);
		System.out.println(ctime);
	}
}
