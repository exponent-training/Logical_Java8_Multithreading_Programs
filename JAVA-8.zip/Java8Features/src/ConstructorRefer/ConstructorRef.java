package ConstructorRefer;

public class ConstructorRef {

	ConstructorRef(String str) {
		System.out.println(str);
		System.out.println(str);
	}

}
