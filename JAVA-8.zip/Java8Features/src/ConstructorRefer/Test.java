package ConstructorRefer;

public interface Test {

	ConstructorRef Message(String str);
}
