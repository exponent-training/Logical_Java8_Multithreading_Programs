package ConstructorRefer;

public class Application {

	public static void main(String[] args) {

		Test t = ConstructorRef::new;
		t.Message("helloworld");
	}
}
