package StreamAPI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String... args) {

//		Stream.of(1, 5, 2, 4, 8, 7, 5).forEach(System.out::println);
//
//		Stream<String> str = Stream.of(new String[] { "anc", "hyf", "fdg" });
//		str.forEach(n -> System.out.println(n));

//		int a[] = { 1, 1, 5, 5, 4, 4, 2 };
//		// array max element
//		int max = Arrays.stream(a).max().getAsInt();
//		System.out.println(max);
//
//		System.out.println("==============================");
//		// array min element
//		int min = Arrays.stream(a).min().getAsInt();
//		System.out.println(min);
//
//		System.out.println("==============================");
//		// array max count element
//		long cnt = Arrays.stream(a).count();
//		System.out.println(cnt);
//
//		System.out.println("==============================");
//		// array min count element
//		long mincnt = Arrays.stream(a).count();
//		System.out.println(mincnt);
//
//		System.out.println("==============================");
//		// array even element
//		long evencount = Arrays.stream(a).filter(n -> n % 2 == 0).count();
//		System.out.println(evencount);
//
//		System.out.println("==============================");
//		// array odd count element
//		long oddcount = Arrays.stream(a).filter(n -> !(n % 2 == 0)).count();
//		System.out.println(oddcount);
//
//		System.out.println("==============================");
//		// array sort element
//		Arrays.stream(a).sorted().forEach(System.out::println);
//
//		System.out.println("==============================");
//		// array distinct element
//		Arrays.stream(a).distinct().forEach(System.out::println);

//		System.out.println("==============================");
//		String s[] = { "aman", "manoj", "abhi", "abhishek", "ajas" };
//		Long satrtwithausercount = Arrays.stream(s).filter(n -> n.startsWith("a")).count();
//		System.out.println(satrtwithausercount);

		List<Integer> listofintegers = Arrays.asList(4, 5, 3, 2, 1, 34, 2, 1, 1);
		listofintegers.stream().filter(n -> n < 5).collect(Collectors.toList()).forEach(System.out::println);
		System.out.println("===============");
		listofintegers.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);

	}
}
