package FunctionalInterfaceExample;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class ExamplePredicate {

	public static void main(String[] args) {

		Predicate<Integer> pin = a -> a > 14;
		System.out.println(pin.test(55));

		List<Integer> l = Arrays.asList(3, 5, 2, 4, 3, 5, 6);
		int cnt = 0;
		Predicate<Integer> p = a -> a % 2 == 0;
		for (Integer v : l) {
			if (p.test(v)) {
				cnt++;
				System.out.println(v);
			}
		}
		System.out.println("Even number count : - " + cnt);
	}
}
