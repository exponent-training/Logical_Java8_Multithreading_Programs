package FunctionalInterfaceExample;

import java.util.ArrayList;
import java.util.List;

public class ForeachmethodUse {

	public static void main(String[] args) {

		List<String> dummy = new ArrayList<String>();
		dummy.add("xyz");
		dummy.add("abc");
		dummy.add("pqr");

//		for (String st : dummy) {
//			System.out.println(st);
//		}

		dummy.forEach(n -> System.out.println(n));

	}

}
