package FunctionalInterfaceExample;

import java.util.function.Supplier;

public class Examplesupplier {

	public static void main(String[] args) {

		Supplier<String> Ssupply = () -> {

			String s = "hello";

			return s;

		};

		System.out.println(Ssupply.get());
	}
}
