package FunctionalInterfaceExample;

import java.util.Optional;

public class ExampleOptionalClass {

	public static void main(String[] args) {

//		String[] s = new String[5];
//		for (String v : s) {
//			v.toLowerCase();
//			System.out.println(v);
//		}

		String[] s = new String[5];
		s[4] = "hello";
		Optional<String> opt = Optional.ofNullable(s[4]);
		if (opt.isPresent()) {
			System.out.println(s[4].toUpperCase());
		} else {
			System.out.println("String is null");
		}
	}
}
