package com.Exponent.Consumer;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

import javax.management.StringValueExp;

public class ConsumerExample {

	public static void main(String[] args) {

//		Consumer con = (n) -> {
//			System.out.println(n);
//		};
//		con.accept("Hello World");

		List<Integer> numbers = Arrays.asList(3, 5, 6, 7, 78, 45, 3, 4, 5, 5);

		Consumer<Integer> sqrNumbers = (n) -> {

			System.out.println("Squar of " + n + " is " + (n * n));

		};

		numbers.forEach(sqrNumbers);

		List<String> stringValues = Arrays.asList("apple", "fruit", "car", "home");

		Consumer<String> stringEachValues = (words) -> {

			stringValues.set(stringValues.indexOf(words), words.toUpperCase());

		};

		stringValues.forEach(stringEachValues);

		System.out.println(stringValues);

	}

}
