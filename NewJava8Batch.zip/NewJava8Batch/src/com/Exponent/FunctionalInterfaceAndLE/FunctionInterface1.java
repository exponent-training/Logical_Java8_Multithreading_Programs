package com.Exponent.FunctionalInterfaceAndLE;

@FunctionalInterface
public interface FunctionInterface1 {

	public int m1(int a, int b);

	default void m2() {
		System.out.println("hi");
	}
}
