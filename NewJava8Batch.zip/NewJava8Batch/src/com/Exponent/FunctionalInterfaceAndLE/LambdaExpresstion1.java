package com.Exponent.FunctionalInterfaceAndLE;

public class LambdaExpresstion1 {

	public static void main(String[] args) {

		FunctionInterface1 f1 = (x, y) -> x * y;
		System.out.println(f1.m1(5, 6));
		f1.m2();
	}
}
