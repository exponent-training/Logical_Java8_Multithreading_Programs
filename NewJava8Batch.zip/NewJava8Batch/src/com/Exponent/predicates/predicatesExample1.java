package com.Exponent.predicates;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class predicatesExample1 {

	public static void main(String[] args) {

		List<Integer> numbers = Arrays.asList(35, 4, 5, 6, 7, 7, 44, 2, 4, 54, 656, 5);

		Predicate<Integer> pred1 = (num) -> num % 2 == 0;
		for (Integer integer : numbers) {
			if (!(pred1.test(integer))) {
				System.out.println(integer);
			}
		}

	}
}
