package com.Exponent.predicates;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import com.Exponent.OptionalClass.Student;

public class Application {

	public static void main(String[] args) {

		List<Employee> listOfEmp = new ArrayList<Employee>();
		listOfEmp.add(new Employee(1, "pratik", 15000.0, 22));
		listOfEmp.add(new Employee(2, "karan", 100000.0, 45));
		listOfEmp.add(new Employee(3, "rahil", 25000.0, 26));
		listOfEmp.add(new Employee(4, "pravin", 55000.0, 24));
		listOfEmp.add(new Employee(5, "pankaj", 1500000.0, 55));

//		Predicate<Employee> ageLessThan30 = (n) -> n.getAge() <= 30;
//
//		List<Employee> lessThan30Emp = new ArrayList<Employee>();
//
//		for (Employee employee : listOfEmp) {
//			if (ageLessThan30.test(employee)) {
//				lessThan30Emp.add(employee);
//			}
//		}
//
//		System.out.println("-----Less than 30 Age------");
//		System.out.println(lessThan30Emp);

		Predicate<Employee> onlyPnames = (n) -> n.getEname().toLowerCase().startsWith("p");
		for (Employee employee : listOfEmp) {
			if (onlyPnames.test(employee)) {
				System.out.println(employee);
			}
		}
	}
}
