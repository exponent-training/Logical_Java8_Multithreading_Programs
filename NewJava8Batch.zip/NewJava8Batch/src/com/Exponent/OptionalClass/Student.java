package com.Exponent.OptionalClass;

import java.util.Optional;

public class Student {

	private String Name;

	private Integer age;

	public Student(String name, Integer age) {
		super();
		Name = name;
		this.age = age;
	}

	public Optional<Integer> getAge() {
		return Optional.ofNullable(age);
	}
	
//	public Integer getAge() {
//		return age;
//	}
}
