package com.Exponent.OptionalClass;

public class Application {

	public static void main(String[] args) {

		Student s = new Student("rahul", 23);

		Student s1 = new Student("pravin", 55);

		System.out.println(s.getAge());

		System.out.println(s1.getAge());
		if (s1.getAge().isPresent()) {
			System.out.println("It doesnt have null value you can proceed");
		} else {
			System.out.println("It contains null");
		}
	}
}
