package com.Exponent.OptionalClass;

import java.util.Optional;

public class OptionalExample {

	public static void main(String[] args) {
		String str[] = new String[10];
//		str[3] = "EXPONENT IT";
		Optional<String> opt = Optional.ofNullable(str[3]);
//		System.out.println(opt.get());
//		System.out.println(opt.hashCode());
		if (opt.isPresent()) {
			System.out.println("Value is present You can Proceed ,there is no null value");
		} else {
			System.out.println("There is null value");
		}

	}
}
