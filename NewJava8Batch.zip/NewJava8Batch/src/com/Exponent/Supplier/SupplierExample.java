package com.Exponent.Supplier;

import java.util.function.Supplier;

public class SupplierExample {

	public static void main(String[] args) {

		Supplier<Student> supplyStudent = () -> {

			Student s = new Student();

			s.setSid(1);
			s.setSname("abc");

			return s;

		};
		
		System.out.println(supplyStudent.get());
	}
}
