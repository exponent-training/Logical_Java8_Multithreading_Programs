package com.DefaultAndStatic.Case1;

public class Main implements Interface1 {

	public static void main(String[] args) {

		Interface1 i = new Main();
		i.show();
		
	}
}
