package com.DefaultAndStatic.Case1;

public interface Interface1 {

	default void show() {
		System.out.println("this is default method from Interface1");
	}
}
