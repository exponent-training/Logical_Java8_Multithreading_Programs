package com.DefaultAndStatic.Case2;

public interface Interface3 {
	default void show() {
		System.out.println("this is default method from Interface3");
	}
}
