package com.DefaultAndStatic.Case2;

public class Main implements Interface2, Interface3 {

	@Override
	public void show() {

		System.out.println("Show Method From Main");
	}

	public static void main(String[] args) {

		Main m = new Main();
		m.show();
	}

}
