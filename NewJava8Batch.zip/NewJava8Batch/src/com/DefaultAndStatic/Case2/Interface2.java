package com.DefaultAndStatic.Case2;

public interface Interface2 {

	default void show() {
		System.out.println("this is default method from Interface2");
	}
}
