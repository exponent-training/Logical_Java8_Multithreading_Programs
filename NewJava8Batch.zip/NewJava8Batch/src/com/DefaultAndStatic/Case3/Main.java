package com.DefaultAndStatic.Case3;

public class Main extends A implements Interface4, Interface5 {

	public static void main(String[] args) {

		Main m = new Main();
		m.show();
	}

}
