package com.DefaultAndStatic.Case3;

public interface Interface5 {
	default void show() {
		System.out.println("this is default method from Interface5");
	}
}
