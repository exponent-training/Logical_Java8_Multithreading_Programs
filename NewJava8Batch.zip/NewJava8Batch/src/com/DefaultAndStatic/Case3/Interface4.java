package com.DefaultAndStatic.Case3;

public interface Interface4 {

	default void show() {
		System.out.println("this is default method from Interface4");
	}
}
