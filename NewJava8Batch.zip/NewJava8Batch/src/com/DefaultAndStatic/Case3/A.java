package com.DefaultAndStatic.Case3;

public class A {

	public void show() {
		System.out.println("I am From Class A");
	}
}
