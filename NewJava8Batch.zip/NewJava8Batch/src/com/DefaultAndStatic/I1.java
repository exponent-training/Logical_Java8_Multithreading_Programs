package com.DefaultAndStatic;

public interface I1 {
//	public abstract void show();

	default void m1() {
		System.out.println("This is Default methos from I1");
	}

	static void m2() {

		System.out.println("This is Static method From I1");

	}

}
